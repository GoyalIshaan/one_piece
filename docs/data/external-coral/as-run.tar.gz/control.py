"""Eight batches of scripted best-so-far multistart with four restarts each."""
import hashlib
import json
from pathlib import Path
import sys
import time

import packing as p

def run():
    out = p.root / (p.family + "-control-" + sys.argv[2])
    out.mkdir(parents=True, exist_ok=False)
    rep = int(sys.argv[2])
    start_time = time.monotonic()
    start_cpu = time.process_time()
    source = p.directory / "seed" / "initial_program.py"
    if not source.exists():
        source.parent.mkdir(parents=True, exist_ok=True)
        rel = source.relative_to(p.root / "upstream")
        source.write_bytes(p.urlopen(f"https://raw.githubusercontent.com/Human-Agent-Society/CORAL/{p.PIN}/{rel}", timeout=20).read())
    released = p.scope["_run_evaluation"](str(source), 15, [sys.executable])
    rect = p.n == 21
    starter = p.check(p.np.array([[(k%7+.5)*.2,(k//7+.5)*.2,.1-1e-12] for k in range(21)])) if rect else p.check(p.initial())
    best = starter
    widths = [1.4,1.33,1.25,1.18,1.12,1.06,1.,1.2] if rect else [1.]*8
    history = []
    for k,w in enumerate(widths):
        q = dict(width=w, sigma=.04, seed=rep*10000+k, count=4, parent=best["circles"])
        result = p.search(q)
        c = result["best"]
        if c and c["raw"] > best["raw"]:
            best = c
        history.append(dict(width=w, seed=q["seed"], scores=result["scores"], bestSoFar=best["raw"]))
    receipt = dict(family=p.family, rep=rep, released=released, upstream=p.PIN, seedSha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                   starter=starter["raw"], history=history, best=p.check(p.np.asarray(best["circles"])),
                   elapsed=time.monotonic()-start_time, processCpuSeconds=time.process_time()-start_cpu)
    (out/"result.json").write_text(json.dumps(receipt, indent=2)+"\n")
    print(p.family, rep, receipt["best"]["raw"], receipt["elapsed"])

if __name__=="__main__":
    run()

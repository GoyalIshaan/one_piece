"""Continuous packing search and immutable CORAL subprocess verification."""
import ast
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
import textwrap
from urllib.request import urlopen

import numpy as np
from scipy.optimize import minimize

PIN = "0123dfb939b35228cf2c1fde224cd0561e727408"
root = Path(os.environ.get("CORAL_DIR", ".one_piece/external-coral")).resolve()
family = sys.argv[1]
if family not in ("circle_packing", "circle_packing_rect"):
    raise ValueError("Unknown family")
n = 26 if family == "circle_packing" else 21
directory = root / "upstream" / "examples" / "math" / family
grader_path = directory / "grader" / "src" / (family + "_grader") / "grader.py"
expected = {"circle_packing": "fe410f41114ffe3bcd6439356f4cab3f5d0e71a28bc79c7ea03658f729f32654", "circle_packing_rect": "8f6364b3948397775702716a7160243cb01fd5e82cd63bc8a6b1549e168db177"}
if not grader_path.exists():
    grader_path.parent.mkdir(parents=True, exist_ok=True)
    relative = grader_path.relative_to(root / "upstream")
    grader_path.write_bytes(urlopen(f"https://raw.githubusercontent.com/Human-Agent-Society/CORAL/{PIN}/{relative}", timeout=20).read())
content = grader_path.read_bytes()
grader_hash = hashlib.sha256(content).hexdigest()
if grader_hash != expected[family]:
    raise ValueError("Unexpected upstream checker")
# The pinned rectangle template produces an invalid f-string even for valid input.
# The opt-in repair edits only the text for the invalid-shape branch.
if n == 21 and os.environ.get("CORAL_RECT_DIAGNOSTIC") == "1":
    before = b'expected ({{}}, 3)".format(NUM_CIRCLES)'
    after = b'expected ({NUM_CIRCLES}, 3)"'
    if content.count(before) != 1:
        raise ValueError("Unexpected rectangle checker text")
    content = content.replace(before, after)
effective_hash = hashlib.sha256(content).hexdigest()
syntax = ast.parse(content)
parts = [s for s in syntax.body if isinstance(s, ast.Assign) or isinstance(s, ast.FunctionDef) and s.name == "_run_evaluation"]
scope = dict(os=os, json=json, textwrap=textwrap)
exec(compile(ast.Module(parts, []), str(grader_path), "exec"), scope)
eye = np.eye(n)
i, j = np.triu_indices(n, 1)
row = np.arange(len(i))
diff = eye[i] - eye[j]
both = eye[i] + eye[j]
zeros = np.zeros_like(eye)
walls = np.block([[eye,zeros,-eye],[-eye,zeros,-eye],[zeros,eye,-eye],[zeros,-eye,-eye]])

def margins(c):
    x, y, r = c.T
    pair = np.hypot(x[i]-x[j], y[i]-y[j]) - r[i] - r[j]
    if n == 26:
        edge = min((x-r).min(), (y-r).min(), (1-x-r).min(), (1-y-r).min())
    else:
        edge = 2 - ((x+r).max() - (x-r).min() + (y+r).max() - (y-r).min())
    return min(float(edge), float(pair.min()), float(r.min()))

def check(c):
    if c.shape != (n,3) or not np.isfinite(c).all() or margins(c) < 0:
        raise ValueError("Strict independent geometry check failed")
    data = c.tolist()
    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / "witness.py"
        p.write_text("def run():\n    c = "+repr(data)+"\n    return "+
                     ("[p[:2] for p in c], [p[2] for p in c], sum(p[2] for p in c)" if n == 26 else "c")+"\n")
        answer = scope["_run_evaluation"](str(p), 15, [sys.executable])
    value = answer.get("sum_radii", answer.get("radii_sum"))
    if value is None or not np.isclose(value, c[:,2].sum(), atol=1e-12,rtol=0):
        raise ValueError(str(answer))
    return dict(circles=data, raw=value, normalized=answer["score"], slack=margins(c), grader=grader_hash,effectiveGrader=effective_hash)

def solve(center, radii, width):
    height = 2-width
    offset = np.repeat([0,width,0,height], n)
    def con(z):
        x,y,r = z.reshape(3,n)
        return np.r_[walls@z + offset,(x[i]-x[j])**2+(y[i]-y[j])**2-(r[i]+r[j])**2]
    def jac(z):
        x,y,r = z.reshape(3,n)
        return np.vstack([walls,np.hstack([2*(x[i]-x[j])[:,None]*diff,2*(y[i]-y[j])[:,None]*diff,-2*(r[i]+r[j])[:,None]*both])])
    objective=np.repeat([0.,0.,-1.],n)
    result=minimize(lambda z: objective@z,np.r_[center.T.flatten(),radii],jac=lambda z:objective,
                    method="SLSQP",bounds=[(0,width)]*n+[(0,height)]*n+[(0,min(width,height)/2)]*n,
                    constraints=[dict(type="ineq",fun=con,jac=jac)],options=dict(maxiter=160,ftol=1e-10))
    c=result.x.reshape(3,n).T.copy()
    c[:,2]=np.maximum(c[:,2]-2e-9,0)
    return c

def initial():
    if n==26:
        return np.array(json.loads(Path("notes/circle-packing-26-calibration.json").read_text())["circles"])
    return np.zeros((n,3))

def search(q):
    width=1 if n==26 else float(q.get("width",1))
    if not .15 <= width <= 1.85: raise ValueError("width outside [.15,1.85]")
    height=2-width
    rng=np.random.default_rng(int(q.get("seed",0)) % (2**32))
    count=int(q.get("count",4))
    if not 1 <= count <= 8: raise ValueError("count must be 1..8")
    sigma=float(q.get("sigma",.04))
    if not 0 <= sigma <= .5: raise ValueError("sigma must be in [0,.5]")
    move=int(q.get("relocate",0))
    if not 0 <= move <= n: raise ValueError("relocate must be 0..N")
    c=np.array(q.get("parent", initial()),dtype=float)
    if "rows" in q:
        rows=q["rows"]
        if not rows or any(type(v)!=int or v<1 for v in rows) or sum(rows)!=n: raise ValueError("rows must sum to circle count")
        offset=float(q.get("offset",0))
        c=np.array([[(col+.5+offset*((k%2)-.5))/v*width,(k+.5)/len(rows)*height,.06] for k,v in enumerate(rows) for col in range(v)])
    elif "centers" in q:
        centers=np.array(q["centers"],dtype=float)
        if centers.shape!=(n,2) or not np.isfinite(centers).all(): raise ValueError("bad centers")
        c=np.c_[centers,np.full(n,.06)]
    elif n==21 and not c.any():
        c=np.array([[(col+.5)/7*width,(k+.5)/3*height,.06] for k in range(3) for col in range(7)])
    best=None
    scores=[]
    for _ in range(count):
        xy=c[:,:2].copy()+rng.normal(0,sigma,(n,2))
        if move:
            ids=np.argsort(c[:,2])[:move] if q.get("smallest",True) else rng.choice(n,move,replace=False)
            xy[ids]=rng.random((move,2))*[width,height]
        cand=solve(np.clip(xy,[0,0],[width,height]),np.minimum(c[:,2],min(width,height)/2),width)
        feasible=margins(cand)>=0
        val=float(cand[:,2].sum()) if feasible else None
        scores.append(val)
        if feasible and (best is None or val>best[:,2].sum()): best=cand
    return dict(scores=scores,best=check(best) if best is not None else None)

if __name__=="__main__":
    q=json.load(sys.stdin)
    result=check(initial()) if q.get("mode")=="starter" else check(np.asarray(q["circles"])) if q.get("mode")=="verify" else search(q)
    print(json.dumps(result, allow_nan=False))

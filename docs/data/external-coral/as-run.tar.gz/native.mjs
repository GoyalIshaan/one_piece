import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { existsSync, mkdirSync, readFileSync } from "node:fs";
import { join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { obj, str } from "@earendil-works/pi-schema";
import { defineTool } from "@one-piece/core";
import { createHarness } from "@one-piece/engine";
import { boardModule } from "@one-piece/module-board";
import { Router, PROVIDER_FACTORIES } from "@one-piece/router";
import { SqliteStore } from "@one-piece/store";
import { homeDir, loadConfig } from "../../../cli/src/config.ts";
import { model, prompts, save } from "../swarm-study/common.mjs";

const [family, label = "rep1", arm = "ordinary"] = process.argv.slice(2);
if (!["circle_packing", "circle_packing_rect"].includes(family) || !["ordinary", "checkpoint"].includes(arm) || !/^[a-z0-9-]+$/.test(label))
	throw new Error("Usage: node native.mjs circle_packing|circle_packing_rect label ordinary|checkpoint");
const n = family === "circle_packing" ? 26 : 21;
const root = resolve(process.env.CORAL_DIR ?? ".one_piece/external-coral");
const dir = join(root, family + "-" + label + "-" + arm);
if (existsSync(dir)) throw new Error("Use a new run label");
mkdirSync(dir, { recursive: true });
const script = fileURLToPath(new URL("./packing.py", import.meta.url));
const cap = 65000, deadline = 180000, slots = 8, batch = 4;
const digest = (s) => createHash("sha256").update(s).digest("hex");
const search = (q) => new Promise((ok, fail) => {
	const proc = spawn("python3", [script, family], { env: { ...process.env, OPENBLAS_NUM_THREADS: "1", VECLIB_MAXIMUM_THREADS: "1", OMP_NUM_THREADS: "1" } });
	let out = "", err = "";
	const timeout = setTimeout(() => proc.kill("SIGKILL"), 40000);
	proc.stdout.on("data", (data) => out += data);
	proc.stderr.on("data", (data) => err += data);
	proc.on("error", (error) => { clearTimeout(timeout); fail(error); });
	proc.on("close", (code) => {
		clearTimeout(timeout);
		try {
			if (code !== 0) throw new Error(err.slice(-1200) || "Optimizer timed out");
			ok(JSON.parse(out));
		} catch (error) { fail(error); }
	});
	proc.stdin.end(JSON.stringify(q));
});
const incumbent = n === 26 ? await search({mode:"starter"}) : await search({mode:"verify",circles:Array.from({length:21},(_,k)=>[(k%7+.5)*.2,(Math.floor(k/7)+.5)*.2,.1-1e-12])});
const provider = loadConfig(process.cwd(), ["openai"]).providers[0];
const router = new Router({
	providers: [{...provider,models:{default:model.id},offer:[]}],
	credentialsPath: join(homeDir(), "auth.json"),
	requestWindowDir: join(root,"provider-windows"),
	providerFactories: PROVIDER_FACTORIES,
});
await router.prepare();
const store = new SqliteStore(join(dir,"trace.db"));
const board = boardModule();
let archive = new Map([["starter",incumbent]]), history = [], first = null, tokens = 0, timedOut = false, started = 0;
const best = () => [...archive].sort((a,b)=>b[1].raw-a[1].raw)[0];
const active = () => !first && tokens < cap && Date.now()-started < deadline;
const status = () => ({best:best()[0],raw:best()[1].raw,slotsLeft:slots-history.length,pending:history.filter(x=>x.status==="working").length,completed:history.filter(x=>x.status!=="working").map(x=>({id:x.id,raw:x.raw,status:x.status}))});
const info = "Construct "+n+" disjoint circles maximizing the radius sum "+(n===26?"in the unit square.":"in any rectangle of width + height = 2.")+
	" Starter raw sum "+incumbent.raw+". In terminal JS return await tools.packing_search({spec:JSON.stringify({...})}). It runs four continuous SLSQP restarts on your chosen starting geometry; each team has eight batch slots. JSON options: parent (verified id, default starter), sigma (absolute Gaussian center jitter), seed (integer), relocate (number of circles randomly repositioned), smallest (true = choose smallest, false = random). Or supply rows (positive integers summing to N), offset (alternating horizontal row shift, units of cell widths), or centers (explicit Nx2 coordinates), and rectangle width if applicable. Different starting topologies and new coordinates allowed. Use packing_status({}) to read results, packing_read({id}) for coordinates, packing_submit({id}) to freeze the team's first nomination. Only completed feasible witnesses can be nominated.";
const mod = {
	manifest:{name:"geometry",version:"1",roles:["leaf"],tools:["packing_search","packing_status","packing_read","packing_submit"],summary:"Construct and score continuous circle packings",contextCostTokens:500},
	prompt:()=>info,
	tools:({node})=>[
		defineTool({name:"packing_status",description:"Read shared optimizer ledger and remaining credits",parameters:obj({}),async execute(){return JSON.stringify(status());}}),
		defineTool({name:"packing_read",description:"Get all coordinates and radii of an archived witness",parameters:obj({id:str()}),async execute({id}){return JSON.stringify(archive.get(id)??"unknown");}}),
		defineTool({name:"packing_search",description:"Run four new continuous optimizations from a geometry or its mutation, returning the best feasible witness",parameters:obj({spec:str()}),async execute({spec}){
			if (!active() || history.length>=slots) return JSON.stringify(status());
			const q=JSON.parse(spec);
			const parent=archive.get(q.parent??"starter");
			if (!parent) throw new Error("Unknown parent");
			const id="p"+(history.length+1), row={id,node:node.id,q,status:"working",ms:Date.now()-started};
			history.push(row);
			try {
				const {best:c,scores} = await search({...Object.fromEntries(Object.entries(q).filter(([k])=>["rows","centers","sigma","seed","relocate","smallest","offset","width"].includes(k))),parent:parent.circles,count:batch});
				row.scores=scores;
				if(c) {archive.set(id,c);save(join(dir,id+".json"),c);row.raw=c.raw;}
				row.status=c?"feasible":"all-invalid";
			} catch(e){row.status="error";row.error=String(e);}
			row.finishedMs=Date.now()-started;
			save(join(dir,"history.json"),history);
			return JSON.stringify({id,result:row,...status()});
		}}),
		defineTool({name:"packing_submit",description:"Freeze one verified witness by id after research",parameters:obj({id:str()}),async execute({id}){
			if(!active() || !archive.has(id))return "Closed or unknown witness";
			first={id,node:node.id,tokens,elapsed:Date.now()-started,raw:archive.get(id).raw,bestAtNomination:best()[1].raw};
			setImmediate(()=>h.finishRun("done","First nomination received"));
			return "Confirmed";
		}}),
	],
};
const h=createHarness({router,store,modules:[board,mod],config:{runDir:dir,environment:{agents:2},thinkingLevel:"low",swarmAgentPrompt:prompts.deployed,peerToolMode:"files",profile:{board:"active",geometry:"active"}}});
let checkpointAt=null;
const stop=h.bus.on(e=>{
	if(e.type!=="model.call") return;
	tokens+=Number(e.data.totalTokens??0);
	if(arm==="checkpoint" && !checkpointAt && active() && tokens>=22000 && e.nodeId && !h.tree.isTerminal(e.nodeId)){
		checkpointAt={tokens,elapsed:Date.now()-started};
		h.deliver(e.nodeId,"Budget checkpoint. Check the optimizer ledger and publish the strongest verified result before resources expire.");
	}
});
let timer;
try{
	started=Date.now();
	const run=await h.start({title:"Optimize and nominate a circle packing",text:"Autonomously coordinate to find a stronger feasible geometry than the starter. Improve the team's first submitted radius sum within eight batches and a three-minute deadline. Explicitly submit your strongest verified geometry before the end."},{tokens:cap});
	timer=setTimeout(()=>{timedOut=true;h.finishRun("stopped","Deadline")},Math.max(1,deadline-(Date.now()-started)));
	await h.done;
	const calls=store.events(run.id,{types:["model.call"]});
	const winner=first?archive.get(first.id):null;
	const verification=winner?await search({mode:"verify",circles:winner.circles}):null;
	const result={family,label,arm,run:run.id,design:{cap,deadline,slots,batch,peers:2,model,grader:incumbent.grader,worker:digest(readFileSync(script)),runner:digest(readFileSync(new URL(import.meta.url)))},incumbent,first,verification,bestEver:{id:best()[0],raw:best()[1].raw},history,checkpointAt,timedOut,tokens,elapsedMs:Date.now()-started,calls:calls.length,errors:calls.filter(e=>e.data.stopReason==="error").length,aborts:calls.filter(e=>e.data.stopReason==="aborted").length};
	save(join(dir,"result.json"),result);
	console.log(JSON.stringify({family,label,arm,first,best:result.bestEver,tokens,elapsedMs:result.elapsedMs,calls:result.calls,timedOut}));
}finally{clearTimeout(timer);stop();await board.dispose?.();store.close();}
